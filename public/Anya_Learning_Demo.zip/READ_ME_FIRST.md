# Anya learning demo — fictional receipts only

Use the test workspace and an executive with an open Denver trip covering November 4–6, 2026. The optional sample workspace has one. This demo does not send email or publish calendar events.

1. Upload learning-training-receipts.csv. The existing date/city matcher should suggest the Denver trip. Change each Verve Mobility charge from Misc. to Transportation, confirm its trip, and choose Just this transaction. No permanent rule is needed yet.
2. Upload learning-next-receipt.csv. It should show a learned Transportation suggestion with three supporting prior decisions. Use the suggestion and confirm the trip. Optionally expand Category memory & feedback, check Remember Transportation, and leave the scope as This vendor in this city. Save transaction & category preference; this does not pin future receipts to that trip.
3. Upload learning-auto-receipt.csv. Transportation should fill in automatically from the confirmed preference, with a source explanation. The normal trip match remains separate.
4. Open Anya memory to inspect evidence, pause pattern learning, forget or restore a preference.

If you have already run this demo, repeated receipts may be detected as duplicates. Use a separate fictional executive/trip for a fresh test; do not delete real records to reset a demo. The new model has no preloaded preferences or real-world accuracy claim.
